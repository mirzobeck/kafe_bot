from aiogram.types import ReplyKeyboardMarkup

asosiy = ReplyKeyboardMarkup(resize_keyboard=True)
asosiy.row("Menu", "Savatcha")


