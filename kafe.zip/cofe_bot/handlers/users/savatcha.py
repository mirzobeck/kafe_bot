from loader import dp
from aiogram import types
from aiogram.dispatcher import FSMContext
from states.st import anketa


@dp.message_handler(text='Savatcha 🛒', state=anketa.category)
async def korzina(message: types.Message, state: FSMContext):
    data = await state.get_data()
    od = data.get('odi')
    cart = data.get('cart')
    msg = ""
    for c in cart:
        msg += f"{c['name']} x {c['amount']}\n"

    await message.answer(msg)


@dp.message_handler(text='Savatcha 🛒', state=anketa.product)
async def korzina(message: types.Message, state: FSMContext):
    data = await state.get_data()
    od = data.get('odi')
    cart = data.get('cart')
    msg = ""
    for c in cart:
        msg += f"{c['name']} x {c['amount']}\n"

    await message.answer(msg)
        
    
    


# @dp.message_handler(text='Savatcha 🛒', state=anketa.product)
# async def korzina(message: types.Message, state: FSMContext):
#     idd = message.from_user.id
#     with open(file=f'E:/NG/Mirzobek_py/Botlar/Malumotlar/{idd}.txt', mode='r') as fayl:
#         r = fayl.read()
#         await message.answer(r)