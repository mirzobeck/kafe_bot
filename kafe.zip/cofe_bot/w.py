s = { 'order': ['name', 'cash', 'price', 5000, 'amount', 5]}

print(s['order'])